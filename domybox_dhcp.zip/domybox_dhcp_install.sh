#!/bin/bash
set -e

export DEBIAN_FRONTEND=noninteractive

apt update
apt install -y isc-dhcp-server jq

# Autoriser www-data à appliquer la config DHCP
cat > /etc/sudoers.d/domybox_dhcp <<EOF
www-data ALL=(root) NOPASSWD:/bin/bash /modules/domybox_dhcp_apply.sh
EOF
chmod 440 /etc/sudoers.d/domybox_dhcp

systemctl enable isc-dhcp-server
systemctl stop isc-dhcp-server || true
