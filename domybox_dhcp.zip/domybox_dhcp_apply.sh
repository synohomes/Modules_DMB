#!/bin/bash
CFG=/tmp/domybox_dhcp.json

iface=$(jq -r .iface $CFG)
subnet=$(jq -r .subnet $CFG)
netmask=$(jq -r .netmask $CFG)
range_start=$(jq -r .range_start $CFG)
range_end=$(jq -r .range_end $CFG)
router=$(jq -r .router $CFG)
dns=$(jq -r .dns $CFG)

sed -i "s/^INTERFACESv4=.*/INTERFACESv4=\"$iface\"/" /etc/default/isc-dhcp-server

cat > /etc/dhcp/dhcpd.conf <<EOF
authoritative;
default-lease-time 600;
max-lease-time 7200;

subnet $subnet netmask $netmask {
  range $range_start $range_end;
  option routers $router;
  option domain-name-servers $dns;
}
EOF

systemctl restart isc-dhcp-server
