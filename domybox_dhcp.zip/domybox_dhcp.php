<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!str_contains((string)($_SESSION['user']['role'] ?? ''), 'admin')) {
    echo "<h3>Accès refusé</h3>";
    return;
}

/* Détection interfaces (même source que le dashboard) */
$raw = [];
exec("ip -o -4 addr show | awk '{print $2\":\"$4}'", $raw);
$interfaces = [];
foreach ($raw as $line) {
    [$iface,$ip] = explode(':', $line);
    $interfaces[$iface] = $ip;
}

/* Statut DHCP */
$status = trim(shell_exec('systemctl is-active isc-dhcp-server'));
$leases = @file_get_contents('/var/lib/dhcp/dhcpd.leases');
$leaseCount = $leases ? substr_count($leases, 'lease ') : 0;

/* Application config */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply'])) {
    $cfg = [
        'iface' => $_POST['iface'],
        'subnet' => $_POST['subnet'],
        'netmask' => $_POST['netmask'],
        'range_start' => $_POST['range_start'],
        'range_end' => $_POST['range_end'],
        'router' => $_POST['router'],
        'dns' => $_POST['dns']
    ];

    file_put_contents('/tmp/domybox_dhcp.json', json_encode($cfg));
    shell_exec('sudo bash /modules/domybox_dhcp_apply.sh');
    header("Location: dashboard.php?page=domybox_dhcp");
    exit;
}
?>

<h2>🛜 Serveur DHCP</h2>

<p>
  <strong>Statut :</strong>
  <?= $status === 'active'
      ? '<span style="color:lime">Actif</span>'
      : '<span style="color:red">Inactif</span>' ?>
</p>

<p><strong>Baux actifs :</strong> <?= (int)$leaseCount ?></p>

<form method="post" style="max-width:500px">

  <label>Interface réseau</label>
  <select name="iface" required>
    <?php foreach ($interfaces as $iface => $ip): ?>
      <option value="<?= htmlspecialchars($iface) ?>">
        <?= htmlspecialchars($iface) ?> (<?= htmlspecialchars($ip) ?>)
      </option>
    <?php endforeach; ?>
  </select>

  <label>Subnet</label>
  <input name="subnet" value="192.168.1.0">

  <label>Masque</label>
  <input name="netmask" value="255.255.255.0">

  <label>Plage DHCP</label>
  <input name="range_start" value="192.168.1.100">
  <input name="range_end" value="192.168.1.150">

  <label>Gateway</label>
  <input name="router" value="192.168.1.1">

  <label>DNS</label>
  <input name="dns" value="8.8.8.8,1.1.1.1">

  <button type="submit" name="apply">💾 Appliquer</button>
</form>
