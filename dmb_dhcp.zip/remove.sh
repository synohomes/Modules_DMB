#!/usr/bin/env bash
set -euo pipefail

LOG="/www/logs/dmd_dhcp.log"
log(){ echo "[$(date '+%F %T')] [remove] $*" >> "$LOG"; }

log "remove start"

rm -f /etc/sudoers.d/dmd_dhcp
rm -f /usr/local/sbin/dmd_dhcp_apply.sh /usr/local/sbin/dmd_dhcp_leases.sh

log "remove done"
exit 0