#!/usr/bin/env bash
set -euo pipefail

MODULE="dmd_dhcp"
LOG="/www/logs/dmd_dhcp.log"

log(){ echo "[$(date '+%F %T')] [install] $*" >> "$LOG"; }

# Ensure logs path (DomyBox standard)
mkdir -p /www/logs
touch "$LOG"
chown -R www-data:www-data /www/logs || true
chmod 0775 /www/logs || true
chmod 0664 "$LOG" || true

export DEBIAN_FRONTEND=noninteractive

log "apt update"
apt-get update -y >>"$LOG" 2>&1

log "install packages isc-dhcp-server php-cli"
apt-get install -y isc-dhcp-server php-cli >>"$LOG" 2>&1

# Root helpers
cat >/usr/local/sbin/dmd_dhcp_apply.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-enable}"   # enable|disable|restart
PHP="/usr/bin/php"
MODDIR="/var/www/html/modules/dmd_dhcp"
LOG="/www/logs/dmd_dhcp.log"
log(){ echo "[$(date '+%F %T')] [root] $*" >> "$LOG"; }

mkdir -p /etc/dhcp

if [[ "$MODE" == "enable" ]]; then
  log "enable: generate /etc/dhcp/dhcpd.conf"
  $PHP "$MODDIR/gen_dhcpd_conf.php" || { log "ERROR: gen_dhcpd_conf failed"; exit 2; }
  log "enable: enable+restart isc-dhcp-server"
  systemctl enable isc-dhcp-server >/dev/null 2>&1 || true
  systemctl restart isc-dhcp-server || { log "ERROR: restart isc-dhcp-server"; systemctl --no-pager -l status isc-dhcp-server || true; exit 3; }
  exit 0
fi

if [[ "$MODE" == "restart" ]]; then
  log "restart: generate /etc/dhcp/dhcpd.conf"
  $PHP "$MODDIR/gen_dhcpd_conf.php" || { log "ERROR: gen_dhcpd_conf failed"; exit 2; }
  log "restart: restart isc-dhcp-server"
  systemctl restart isc-dhcp-server || { log "ERROR: restart isc-dhcp-server"; systemctl --no-pager -l status isc-dhcp-server || true; exit 3; }
  exit 0
fi

if [[ "$MODE" == "disable" ]]; then
  log "disable: stop+disable isc-dhcp-server"
  systemctl stop isc-dhcp-server 2>/dev/null || true
  systemctl disable isc-dhcp-server >/dev/null 2>&1 || true
  exit 0
fi

log "ERROR: bad mode=$MODE"
exit 4
EOF
chmod 0755 /usr/local/sbin/dmd_dhcp_apply.sh

cat >/usr/local/sbin/dmd_dhcp_leases.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
/usr/bin/php /var/www/html/modules/dmd_dhcp/leases_json.php
EOF
chmod 0755 /usr/local/sbin/dmd_dhcp_leases.sh

# Sudoers (strictly only these helpers)
cat >/etc/sudoers.d/dmd_dhcp <<'EOF'
# dmd_dhcp module helpers
www-data ALL=(root) NOPASSWD: /usr/local/sbin/dmd_dhcp_apply.sh
www-data ALL=(root) NOPASSWD: /usr/local/sbin/dmd_dhcp_leases.sh
EOF
chmod 0440 /etc/sudoers.d/dmd_dhcp
visudo -cf /etc/sudoers.d/dmd_dhcp >/dev/null

# Ensure dhcpd.conf exists (safe baseline)
if [[ ! -f /etc/dhcp/dhcpd.conf ]]; then
  echo "# created by dmd_dhcp" >/etc/dhcp/dhcpd.conf
fi

log "install done"
exit 0