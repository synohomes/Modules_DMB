<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/db.php';

require_login();
header('Content-Type: application/json; charset=utf-8');

function out(array $a, int $code=200): void {
  http_response_code($code);
  echo json_encode($a, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}
function csrf_ok(): bool {
  return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals((string)$_SESSION['csrf'], (string)$_POST['csrf']);
}
function log_mod(string $msg): void {
  $f = '/data/modules/logs/dmd_dhcp.log';
  $who = $_SESSION['user']['email'] ?? ($_SESSION['user']['pseudo'] ?? 'unknown');
  $ip  = $_SERVER['REMOTE_ADDR'] ?? '-';
  @file_put_contents($f, sprintf("[%s] [%s] [%s] %s\n", date('Y-m-d H:i:s'), $who, $ip, $msg), FILE_APPEND);
}
function must(bool $c, string $e): void { if(!$c) out(['ok'=>0,'error'=>$e], 400); }
function valid_ip(string $ip): bool { return (bool)filter_var($ip, FILTER_VALIDATE_IP); }
function norm_mac(string $mac): string {
  $m = strtolower(trim($mac));
  $m = str_replace(['-', '.', ' '], ':', $m);
  $m = preg_replace('/:+/', ':', $m) ?? $m;
  return $m;
}
function sudo_run(string $cmd, array &$out=null, int &$rc=null): string {
  $out=[]; $rc=0;
  exec("sudo -n {$cmd} 2>&1", $out, $rc);
  return trim(implode("\n",$out));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok'=>0,'error'=>'method'], 405);
if (!csrf_ok()) out(['ok'=>0,'error'=>'csrf'], 403);

$action = (string)($_POST['action'] ?? '');

/* Ensure tables */
$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_settings (k VARCHAR(64) PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_subnets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(128) NOT NULL,
  iface VARCHAR(64) NOT NULL DEFAULT 'eth0',
  cidr VARCHAR(32) NOT NULL,
  range_start VARCHAR(45) NOT NULL,
  range_end VARCHAR(45) NOT NULL,
  router VARCHAR(45) NOT NULL,
  dns1 VARCHAR(45) NOT NULL,
  dns2 VARCHAR(45) NOT NULL DEFAULT '',
  domain_name VARCHAR(255) NOT NULL DEFAULT '',
  lease_time INT NOT NULL DEFAULT 86400,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subnet_id INT NOT NULL,
  hostname VARCHAR(128) NOT NULL DEFAULT '',
  mac VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_subnet_mac (subnet_id, mac),
  UNIQUE KEY uniq_subnet_ip (subnet_id, ip),
  CONSTRAINT fk_dmd_dhcp_res_subnet FOREIGN KEY (subnet_id) REFERENCES dmd_dhcp_subnets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$st = $pdo->prepare("INSERT IGNORE INTO dmd_dhcp_settings(k,v) VALUES(?,?)");
$st->execute(['dhcp_enabled','0']);

if ($action === 'toggle_module') {
  $cur = (int)($pdo->query("SELECT v FROM dmd_dhcp_settings WHERE k='dhcp_enabled'")->fetchColumn() ?: 0);
  $new = $cur===1 ? 0 : 1;
  $st = $pdo->prepare("UPDATE dmd_dhcp_settings SET v=? WHERE k='dhcp_enabled'");
  $st->execute([(string)$new]);
  log_mod("toggle_module => {$new}");
  out(['ok'=>1,'enabled'=>$new]);
}

if ($action === 'add_subnet') {
  $label = trim((string)($_POST['label'] ?? ''));
  $iface = trim((string)($_POST['iface'] ?? 'eth0'));
  $cidr  = trim((string)($_POST['cidr'] ?? ''));
  $rs    = trim((string)($_POST['range_start'] ?? ''));
  $re    = trim((string)($_POST['range_end'] ?? ''));
  $router= trim((string)($_POST['router'] ?? ''));
  $dns1  = trim((string)($_POST['dns1'] ?? ''));
  $dns2  = trim((string)($_POST['dns2'] ?? ''));
  $domain= trim((string)($_POST['domain_name'] ?? ''));
  $lease = (int)($_POST['lease_time'] ?? 86400);

  must($label !== '', 'label');
  must($iface !== '', 'iface');
  must($cidr !== '' && strpos($cidr,'/') !== false, 'cidr');
  must(valid_ip($rs) && valid_ip($re) && valid_ip($router) && valid_ip($dns1), 'ip');
  must($lease >= 60, 'lease');

  $st = $pdo->prepare("INSERT INTO dmd_dhcp_subnets(label,iface,cidr,range_start,range_end,router,dns1,dns2,domain_name,lease_time,enabled)
                       VALUES(?,?,?,?,?,?,?,?,?,?,1)");
  $st->execute([$label,$iface,$cidr,$rs,$re,$router,$dns1,$dns2,$domain,$lease]);
  $id = (int)$pdo->lastInsertId();
  log_mod("add_subnet id={$id} cidr={$cidr} iface={$iface} range={$rs}-{$re} gw={$router} dns={$dns1}".($dns2?"/{$dns2}":""));
  out(['ok'=>1,'id'=>$id]);
}

if ($action === 'toggle_subnet') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("SELECT enabled FROM dmd_dhcp_subnets WHERE id=?");
  $st->execute([$id]);
  $cur = (int)$st->fetchColumn();
  $new = $cur===1 ? 0 : 1;
  $st = $pdo->prepare("UPDATE dmd_dhcp_subnets SET enabled=? WHERE id=?");
  $st->execute([$new,$id]);
  log_mod("toggle_subnet id={$id} => {$new}");
  out(['ok'=>1,'enabled'=>$new]);
}

if ($action === 'delete_subnet') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("DELETE FROM dmd_dhcp_subnets WHERE id=?");
  $st->execute([$id]);
  log_mod("delete_subnet id={$id}");
  out(['ok'=>1]);
}

if ($action === 'add_reservation') {
  $sid = (int)($_POST['subnet_id'] ?? 0);
  $hostname = trim((string)($_POST['hostname'] ?? ''));
  $mac = norm_mac((string)($_POST['mac'] ?? ''));
  $ip  = trim((string)($_POST['ip'] ?? ''));
  $note= trim((string)($_POST['note'] ?? ''));

  must($sid>0,'subnet');
  must(preg_match('/^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i',$mac)===1,'mac');
  must(valid_ip($ip),'ip');

  $st = $pdo->prepare("SELECT id FROM dmd_dhcp_subnets WHERE id=?");
  $st->execute([$sid]);
  must((int)$st->fetchColumn()>0,'subnet');

  $st = $pdo->prepare("INSERT INTO dmd_dhcp_reservations(subnet_id,hostname,mac,ip,note,enabled) VALUES(?,?,?,?,?,1)");
  try { $st->execute([$sid,$hostname,$mac,$ip,$note]); }
  catch(Throwable $e){ out(['ok'=>0,'error'=>'duplicate_mac_or_ip'], 409); }

  $id = (int)$pdo->lastInsertId();
  log_mod("add_reservation id={$id} subnet={$sid} mac={$mac} ip={$ip} host={$hostname}");
  out(['ok'=>1,'id'=>$id]);
}

if ($action === 'list_reservations') {
  $items = $pdo->query("SELECT * FROM dmd_dhcp_reservations ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  out(['ok'=>1,'items'=>$items]);
}

if ($action === 'toggle_reservation') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("SELECT enabled FROM dmd_dhcp_reservations WHERE id=?");
  $st->execute([$id]);
  $cur = (int)$st->fetchColumn();
  $new = $cur===1 ? 0 : 1;
  $st = $pdo->prepare("UPDATE dmd_dhcp_reservations SET enabled=? WHERE id=?");
  $st->execute([$new,$id]);
  log_mod("toggle_reservation id={$id} => {$new}");
  out(['ok'=>1,'enabled'=>$new]);
}

if ($action === 'delete_reservation') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("DELETE FROM dmd_dhcp_reservations WHERE id=?");
  $st->execute([$id]);
  log_mod("delete_reservation id={$id}");
  out(['ok'=>1]);
}

if ($action === 'apply') {
  $enabled = (int)($pdo->query("SELECT v FROM dmd_dhcp_settings WHERE k='dhcp_enabled'")->fetchColumn() ?: 0);
  log_mod("apply requested ui_enabled={$enabled}");
  $mode = $enabled===1 ? "enable" : "disable";
  $outLines=[]; $rc=0;
  $log = sudo_run("/usr/local/sbin/dmd_dhcp_apply.sh {$mode}", $outLines, $rc);
  if ($rc !== 0) { log_mod("apply FAILED rc={$rc}: ".$log); out(['ok'=>0,'error'=>'apply_failed','details'=>$log], 500); }
  out(['ok'=>1,'log'=>$log]);
}

if ($action === 'leases') {
  $outLines=[]; $rc=0;
  $raw = sudo_run("/usr/local/sbin/dmd_dhcp_leases.sh", $outLines, $rc);
  if ($rc !== 0) { log_mod("leases FAILED rc={$rc}: ".$raw); out(['ok'=>0,'error'=>'leases_failed','details'=>$raw], 500); }
  $j = json_decode($raw, true);
  if (!is_array($j)) out(['ok'=>0,'error'=>'leases_bad_json'], 500);
  out(['ok'=>1,'items'=>$j]);
}

out(['ok'=>0,'error'=>'unknown_action'], 400);