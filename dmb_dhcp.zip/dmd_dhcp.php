<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/db.php';

require_login();

function csrf_token(): string {
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
  return $_SESSION['csrf'];
}
$csrf = csrf_token();

$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_settings (k VARCHAR(64) PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_subnets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(128) NOT NULL,
  iface VARCHAR(64) NOT NULL DEFAULT 'eth0',
  cidr VARCHAR(32) NOT NULL,
  range_start VARCHAR(45) NOT NULL,
  range_end VARCHAR(45) NOT NULL,
  router VARCHAR(45) NOT NULL,
  dns1 VARCHAR(45) NOT NULL,
  dns2 VARCHAR(45) NOT NULL DEFAULT '',
  domain_name VARCHAR(255) NOT NULL DEFAULT '',
  lease_time INT NOT NULL DEFAULT 86400,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmd_dhcp_reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subnet_id INT NOT NULL,
  hostname VARCHAR(128) NOT NULL DEFAULT '',
  mac VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_subnet_mac (subnet_id, mac),
  UNIQUE KEY uniq_subnet_ip (subnet_id, ip),
  CONSTRAINT fk_dmd_dhcp_res_subnet FOREIGN KEY (subnet_id) REFERENCES dmd_dhcp_subnets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$st = $pdo->prepare("INSERT IGNORE INTO dmd_dhcp_settings(k,v) VALUES(?,?)");
$st->execute(['dhcp_enabled','0']);

$enabled = (int)($pdo->query("SELECT v FROM dmd_dhcp_settings WHERE k='dhcp_enabled'")->fetchColumn() ?: 0);
$subnets = $pdo->query("SELECT * FROM dmd_dhcp_subnets ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>dmd_dhcp</title>
  <style>
    *{box-sizing:border-box}
    body{margin:0;padding:16px;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
    .wrap{max-width:1200px;margin:0 auto}
    .top{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}
    .row{display:flex;gap:12px;flex-wrap:wrap}
    .card{flex:1;min-width:320px;border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:12px}
    h1{margin:0;font-size:18px}
    h2{margin:0 0 10px;font-size:14px}
    label{display:block;font-size:12px;margin:10px 0 6px}
    input,select{width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:transparent;color:inherit}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .btn{padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:transparent;color:inherit;cursor:pointer}
    .actions{display:flex;gap:8px;flex-wrap:wrap}
    table{width:100%;border-collapse:separate;border-spacing:0 8px}
    th{font-size:12px;text-align:left;opacity:.8;padding:0 8px}
    td{padding:10px 8px;border:1px solid rgba(255,255,255,.12)}
    tr td:first-child{border-top-left-radius:12px;border-bottom-left-radius:12px}
    tr td:last-child{border-top-right-radius:12px;border-bottom-right-radius:12px}
    code{font-family:ui-monospace,Menlo,Consolas,monospace}
    .pill{display:inline-flex;gap:8px;align-items:center;padding:6px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.12)}
    .dot{width:9px;height:9px;border-radius:99px;background:#777}
    .dot.on{background:#3ddc84}
    .dot.off{background:#ff6b6b}
    .muted{opacity:.75;font-size:12px}
    .toast{position:fixed;right:16px;bottom:16px;max-width:420px;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);display:none}
    .toast.show{display:block}
    @media (max-width:900px){.grid2{grid-template-columns:1fr}}
  </style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <h1>dmd_dhcp — DHCP</h1>
    <div class="actions">
      <span class="pill">
        <span class="dot <?= $enabled ? 'on':'off' ?>"></span>
        <b><?= $enabled ? 'Actif (UI)' : 'Inactif (UI)' ?></b>
        <span class="muted">Appliquer = start/stop service</span>
      </span>
      <button class="btn" id="btnLeases">Leases</button>
      <button class="btn" id="btnApply">Appliquer</button>
      <button class="btn" id="btnToggle"><?= $enabled ? 'Désactiver' : 'Activer' ?></button>
    </div>
  </div>

  <div class="row">
    <div class="card">
      <h2>Sous-réseaux</h2>
      <div class="grid2">
        <div><label>Label</label><input id="sn_label" placeholder="LAN"></div>
        <div><label>Interface</label><input id="sn_iface" placeholder="eth0"></div>
        <div><label>Réseau (CIDR)</label><input id="sn_cidr" placeholder="192.168.10.0/24"></div>
        <div>
          <label>Range</label>
          <div class="grid2">
            <input id="sn_rs" placeholder="192.168.10.50">
            <input id="sn_re" placeholder="192.168.10.200">
          </div>
        </div>
        <div><label>Gateway</label><input id="sn_router" placeholder="192.168.10.1"></div>
        <div>
          <label>DNS (1 / 2)</label>
          <div class="grid2">
            <input id="sn_dns1" placeholder="1.1.1.1">
            <input id="sn_dns2" placeholder="8.8.8.8">
          </div>
        </div>
        <div><label>Domaine (option)</label><input id="sn_domain" placeholder="home.lan"></div>
        <div><label>Lease (secondes)</label><input id="sn_lease" type="number" min="60" step="60" value="86400"></div>
      </div>
      <div class="actions" style="margin-top:10px">
        <button class="btn" id="btnAddSubnet">Ajouter</button>
      </div>

      <div style="margin-top:12px;overflow:auto">
        <table>
          <thead>
            <tr><th>ID</th><th>Label</th><th>IF</th><th>CIDR</th><th>Range</th><th>GW</th><th>DNS</th><th>On</th><th></th></tr>
          </thead>
          <tbody>
          <?php if (!$subnets): ?>
            <tr><td colspan="9" class="muted">Aucun sous-réseau.</td></tr>
          <?php else: foreach ($subnets as $s): ?>
            <tr>
              <td><?= (int)$s['id'] ?></td>
              <td><?= htmlspecialchars((string)$s['label']) ?></td>
              <td><?= htmlspecialchars((string)$s['iface']) ?></td>
              <td><?= htmlspecialchars((string)$s['cidr']) ?></td>
              <td><?= htmlspecialchars((string)$s['range_start']) ?> → <?= htmlspecialchars((string)$s['range_end']) ?></td>
              <td><?= htmlspecialchars((string)$s['router']) ?></td>
              <td><?= htmlspecialchars((string)$s['dns1']) ?><?= $s['dns2'] ? ', '.htmlspecialchars((string)$s['dns2']) : '' ?></td>
              <td><?= ((int)$s['enabled']===1) ? '✅' : '⛔' ?></td>
              <td class="actions">
                <button class="btn" onclick="toggleSubnet(<?= (int)$s['id'] ?>)">On/Off</button>
                <button class="btn" onclick="delSubnet(<?= (int)$s['id'] ?>)">Suppr</button>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <h2>Réservations (MAC → IP)</h2>
      <div class="grid2">
        <div>
          <label>Sous-réseau</label>
          <select id="res_subnet">
            <option value="">— choisir —</option>
            <?php foreach ($subnets as $s): ?>
              <option value="<?= (int)$s['id'] ?>">#<?= (int)$s['id'] ?> — <?= htmlspecialchars((string)$s['label']) ?> (<?= htmlspecialchars((string)$s['cidr']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label>Hostname (option)</label><input id="res_host" placeholder="pc-salon"></div>
        <div><label>MAC</label><input id="res_mac" placeholder="aa:bb:cc:dd:ee:ff"></div>
        <div><label>IP</label><input id="res_ip" placeholder="192.168.10.10"></div>
      </div>
      <label>Note</label>
      <input id="res_note" placeholder="NAS / imprimante / ...">
      <div class="actions" style="margin-top:10px">
        <button class="btn" id="btnAddRes">Ajouter</button>
      </div>

      <div style="margin-top:12px;overflow:auto">
        <table>
          <thead><tr><th>ID</th><th>Subnet</th><th>Hostname</th><th>MAC</th><th>IP</th><th>On</th><th></th></tr></thead>
          <tbody id="resBody"><tr><td colspan="7" class="muted">Chargement…</td></tr></tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="card" style="margin-top:12px">
    <h2>Périphériques connectés (leases)</h2>
    <div class="muted">Depuis = début du bail (dhcpd.leases).</div>
    <div style="margin-top:10px;overflow:auto">
      <table>
        <thead><tr><th>IP</th><th>MAC</th><th>Hostname</th><th>Depuis</th><th>Expire</th><th>État</th></tr></thead>
        <tbody id="leasesBody"><tr><td colspan="6" class="muted">Clique “Leases”.</td></tr></tbody>
      </table>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const CSRF = <?= json_encode($csrf) ?>;

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2400);
}
function esc(s){return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&lt;','"':'&quot;',\"'\":'&#039;'}[m]));}

async function post(action, data={}){
  const fd = new FormData();
  fd.append('csrf', CSRF);
  fd.append('action', action);
  for (const k in data) fd.append(k, data[k]);
  const r = await fetch('api.php', {method:'POST', body:fd});
  const j = await r.json().catch(()=>({ok:0,error:'bad_json'}));
  if (!j.ok) throw new Error(j.error||'error');
  return j;
}

async function loadRes(){
  const j = await post('list_reservations', {});
  const tb = document.getElementById('resBody');
  tb.innerHTML = '';
  if (!j.items || !j.items.length){
    tb.innerHTML = `<tr><td colspan="7" class="muted">Aucune réservation.</td></tr>`;
    return;
  }
  for (const it of j.items){
    tb.insertAdjacentHTML('beforeend', `
      <tr>
        <td>${it.id}</td>
        <td>#${it.subnet_id}</td>
        <td>${esc(it.hostname||'')}</td>
        <td><code>${esc(it.mac)}</code></td>
        <td><code>${esc(it.ip)}</code></td>
        <td>${it.enabled==1?'✅':'⛔'}</td>
        <td class="actions">
          <button class="btn" onclick="toggleRes(${it.id})">On/Off</button>
          <button class="btn" onclick="delRes(${it.id})">Suppr</button>
        </td>
      </tr>
    `);
  }
}

async function loadLeases(){
  const j = await post('leases', {});
  const tb = document.getElementById('leasesBody');
  tb.innerHTML = '';
  if (!j.items || !j.items.length){
    tb.innerHTML = `<tr><td colspan="6" class="muted">Aucun lease.</td></tr>`;
    return;
  }
  for (const it of j.items){
    tb.insertAdjacentHTML('beforeend', `
      <tr>
        <td><code>${esc(it.ip||'')}</code></td>
        <td><code>${esc(it.mac||'')}</code></td>
        <td>${esc(it.hostname||'')}</td>
        <td>${esc(it.start_human||'')}</td>
        <td>${esc(it.end_human||'')}</td>
        <td>${esc(it.state||'')}</td>
      </tr>
    `);
  }
}

async function toggleSubnet(id){ try{ await post('toggle_subnet',{id}); location.reload(); }catch(e){ toast(e.message); } }
async function delSubnet(id){ if(!confirm('Supprimer ce sous-réseau ?')) return; try{ await post('delete_subnet',{id}); location.reload(); }catch(e){ toast(e.message); } }

async function toggleRes(id){ try{ await post('toggle_reservation',{id}); loadRes(); }catch(e){ toast(e.message); } }
async function delRes(id){ if(!confirm('Supprimer cette réservation ?')) return; try{ await post('delete_reservation',{id}); loadRes(); }catch(e){ toast(e.message); } }

document.getElementById('btnAddSubnet').addEventListener('click', async ()=>{
  try{
    await post('add_subnet', {
      label: sn_label.value.trim(),
      iface: sn_iface.value.trim(),
      cidr: sn_cidr.value.trim(),
      range_start: sn_rs.value.trim(),
      range_end: sn_re.value.trim(),
      router: sn_router.value.trim(),
      dns1: sn_dns1.value.trim(),
      dns2: sn_dns2.value.trim(),
      domain_name: sn_domain.value.trim(),
      lease_time: sn_lease.value.trim()
    });
    location.reload();
  }catch(e){ toast(e.message); }
});

document.getElementById('btnAddRes').addEventListener('click', async ()=>{
  try{
    await post('add_reservation', {
      subnet_id: res_subnet.value,
      hostname: res_host.value.trim(),
      mac: res_mac.value.trim(),
      ip: res_ip.value.trim(),
      note: res_note.value.trim()
    });
    res_host.value=''; res_mac.value=''; res_ip.value=''; res_note.value='';
    loadRes();
  }catch(e){ toast(e.message); }
});

document.getElementById('btnApply').addEventListener('click', async ()=>{
  try{ await post('apply',{}); toast('Appliqué'); }catch(e){ toast(e.message); }
});
document.getElementById('btnToggle').addEventListener('click', async ()=>{
  try{ await post('toggle_module',{}); location.reload(); }catch(e){ toast(e.message); }
});
document.getElementById('btnLeases').addEventListener('click', async ()=>{
  try{ await loadLeases(); }catch(e){ toast(e.message); }
});

loadRes();
</script>
</body>
</html>