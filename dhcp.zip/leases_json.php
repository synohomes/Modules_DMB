<?php
declare(strict_types=1);

$leaseFile = '/var/lib/dhcp/dhcpd.leases';
if (!is_file($leaseFile)) {
  echo json_encode([], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}

$txt = (string)file_get_contents($leaseFile);
$lines = preg_split("/\r\n|\n|\r/", $txt);

$leases = [];
$cur = null;

function to_human(?int $ts): string {
  if (!$ts) return '';
  return date('Y-m-d H:i:s', $ts);
}

foreach ($lines as $ln) {
  $ln = trim($ln);

  if (preg_match('/^lease\s+([0-9\.]+)\s+\{$/', $ln, $m)) {
    $cur = [
      'ip' => $m[1],
      'mac' => '',
      'hostname' => '',
      'start' => null,
      'end' => null,
      'state' => '',
      'binding' => '',
    ];
    continue;
  }

  if ($cur !== null) {
    if ($ln === "}") {
      // keep only active/valid? We'll decide later.
      $leases[] = $cur;
      $cur = null;
      continue;
    }

    if (preg_match('/^starts\s+\d+\s+(\d{4}\/\d{2}\/\d{2})\s+(\d{2}:\d{2}:\d{2});$/', $ln, $m)) {
      $cur['start'] = strtotime(str_replace('/','-',$m[1]).' '.$m[2]) ?: null;
      continue;
    }
    if (preg_match('/^ends\s+\d+\s+(\d{4}\/\d{2}\/\d{2})\s+(\d{2}:\d{2}:\d{2});$/', $ln, $m)) {
      $cur['end'] = strtotime(str_replace('/','-',$m[1]).' '.$m[2]) ?: null;
      continue;
    }
    if (preg_match('/^hardware\s+ethernet\s+([0-9a-f:]+);$/i', $ln, $m)) {
      $cur['mac'] = strtolower($m[1]);
      continue;
    }
    if (preg_match('/^client-hostname\s+"([^"]*)";$/', $ln, $m)) {
      $cur['hostname'] = $m[1];
      continue;
    }
    if (preg_match('/^binding\s+state\s+([a-z]+);$/i', $ln, $m)) {
      $cur['binding'] = strtolower($m[1]);
      continue;
    }
  }
}

// Keep only current active lease per IP (latest end time wins)
$byIp = [];
foreach ($leases as $l) {
  $ip = $l['ip'];
  if (!isset($byIp[$ip])) $byIp[$ip] = $l;
  else {
    $a = $byIp[$ip]['end'] ?? 0;
    $b = $l['end'] ?? 0;
    if ($b >= $a) $byIp[$ip] = $l;
  }
}

$now = time();
$out = [];
foreach ($byIp as $ip => $l) {
  $end = (int)($l['end'] ?? 0);
  $binding = (string)($l['binding'] ?? '');
  $state = 'unknown';

  if ($binding === 'active' && ($end === 0 || $end > $now)) $state = 'active';
  else if ($end > 0 && $end <= $now) $state = 'expired';
  else if ($binding !== '') $state = $binding;

  $out[] = [
    'ip' => $ip,
    'mac' => $l['mac'] ?? '',
    'hostname' => $l['hostname'] ?? '',
    'start' => $l['start'],
    'end' => $l['end'],
    'start_human' => to_human(is_int($l['start']) ? $l['start'] : null),
    'end_human' => to_human(is_int($l['end']) ? $l['end'] : null),
    'state' => $state,
  ];
}

// sort by ip
usort($out, function($a,$b){
  return ip2long($a['ip']) <=> ip2long($b['ip']);
});

echo json_encode($out, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);