CREATE TABLE IF NOT EXISTS dmb_dhcp_settings (
  k VARCHAR(64) PRIMARY KEY,
  v TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dmb_dhcp_subnets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(128) NOT NULL,
  iface VARCHAR(64) NOT NULL DEFAULT 'eth0',
  cidr VARCHAR(32) NOT NULL,
  range_start VARCHAR(45) NOT NULL,
  range_end VARCHAR(45) NOT NULL,
  router VARCHAR(45) NOT NULL,
  dns1 VARCHAR(45) NOT NULL,
  dns2 VARCHAR(45) NOT NULL DEFAULT '',
  domain_name VARCHAR(255) NOT NULL DEFAULT '',
  lease_time INT NOT NULL DEFAULT 86400,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dmb_dhcp_reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subnet_id INT NOT NULL,
  hostname VARCHAR(128) NOT NULL DEFAULT '',
  mac VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_subnet_mac (subnet_id, mac),
  UNIQUE KEY uniq_subnet_ip (subnet_id, ip),
  CONSTRAINT fk_dmb_dhcp_res_subnet
    FOREIGN KEY (subnet_id) REFERENCES dmb_dhcp_subnets(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO dmb_dhcp_settings(k,v) VALUES ('dhcp_enabled','0');