#!/usr/bin/env bash
set -euo pipefail

MODULE="dmb_dhcp"
WEBROOT="/var/www/html"
MODDIR="${WEBROOT}/modules/${MODULE}"

echo "[${MODULE}] Installing packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y isc-dhcp-server php-cli

echo "[${MODULE}] Creating root helper scripts..."

cat >/usr/local/sbin/dmb_dhcp_apply.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-enable}"   # enable|disable
PHP="/usr/bin/php"
WEBROOT="/var/www/html"
MODDIR="${WEBROOT}/modules/dmb_dhcp"

if [[ ! -d "$MODDIR" ]]; then
  echo "module_dir_missing"
  exit 1
fi

if [[ "$MODE" == "enable" ]]; then
  # generate dhcpd.conf
  $PHP "$MODDIR/gen_dhcpd_conf.php"

  # Ensure service enabled
  systemctl enable isc-dhcp-server >/dev/null 2>&1 || true

  # Restart service
  systemctl restart isc-dhcp-server

  systemctl --no-pager --full status isc-dhcp-server | head -n 20 || true
  exit 0
fi

if [[ "$MODE" == "disable" ]]; then
  # stop service
  systemctl stop isc-dhcp-server || true
  systemctl disable isc-dhcp-server >/dev/null 2>&1 || true
  echo "disabled"
  exit 0
fi

echo "bad_mode"
exit 2
EOF
chmod 0755 /usr/local/sbin/dmb_dhcp_apply.sh

cat >/usr/local/sbin/dmb_dhcp_leases.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
PHP="/usr/bin/php"
WEBROOT="/var/www/html"
MODDIR="${WEBROOT}/modules/dmb_dhcp"
$PHP "$MODDIR/leases_json.php"
EOF
chmod 0755 /usr/local/sbin/dmb_dhcp_leases.sh

echo "[${MODULE}] Sudoers whitelist for www-data..."
cat >/etc/sudoers.d/dmb_dhcp <<'EOF'
# DomyBox module dmb_dhcp
# Allow ONLY these commands, no password
www-data ALL=(root) NOPASSWD: /usr/local/sbin/dmb_dhcp_apply.sh
www-data ALL=(root) NOPASSWD: /usr/local/sbin/dmb_dhcp_leases.sh
EOF
chmod 0440 /etc/sudoers.d/dmb_dhcp
visudo -cf /etc/sudoers.d/dmb_dhcp >/dev/null

echo "[${MODULE}] Ensure dhcpd conf exists (safe minimal)..."
if [[ ! -f /etc/dhcp/dhcpd.conf ]]; then
  echo "# created by dmb_dhcp install" >/etc/dhcp/dhcpd.conf
fi

echo "[${MODULE}] Done."
exit 0