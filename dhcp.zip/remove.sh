#!/usr/bin/env bash
set -euo pipefail

MODULE="dmb_dhcp"

echo "[${MODULE}] Stopping service..."
systemctl stop isc-dhcp-server || true
systemctl disable isc-dhcp-server >/dev/null 2>&1 || true

echo "[${MODULE}] Removing sudoers & helper scripts..."
rm -f /etc/sudoers.d/dmb_dhcp
rm -f /usr/local/sbin/dmb_dhcp_apply.sh
rm -f /usr/local/sbin/dmb_dhcp_leases.sh

echo "[${MODULE}] Keeping packages (isc-dhcp-server) installed by default."
echo "[${MODULE}] Done."
exit 0