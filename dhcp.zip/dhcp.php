<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/db.php';

require_login();

/* ===== CSRF ===== */
function csrf_token(): string {
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
  return $_SESSION['csrf'];
}
$csrf = csrf_token();

/* ===== Simple migration auto ===== */
function dmb_dhcp_migrate(PDO $pdo): void {
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS dmb_dhcp_settings (
      k VARCHAR(64) PRIMARY KEY,
      v TEXT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS dmb_dhcp_subnets (
      id INT AUTO_INCREMENT PRIMARY KEY,
      label VARCHAR(128) NOT NULL,
      iface VARCHAR(64) NOT NULL DEFAULT 'eth0',
      cidr VARCHAR(32) NOT NULL,
      range_start VARCHAR(45) NOT NULL,
      range_end VARCHAR(45) NOT NULL,
      router VARCHAR(45) NOT NULL,
      dns1 VARCHAR(45) NOT NULL,
      dns2 VARCHAR(45) NOT NULL DEFAULT '',
      domain_name VARCHAR(255) NOT NULL DEFAULT '',
      lease_time INT NOT NULL DEFAULT 86400,
      enabled TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS dmb_dhcp_reservations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      subnet_id INT NOT NULL,
      hostname VARCHAR(128) NOT NULL DEFAULT '',
      mac VARCHAR(32) NOT NULL,
      ip VARCHAR(45) NOT NULL,
      note VARCHAR(255) NOT NULL DEFAULT '',
      enabled TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_subnet_mac (subnet_id, mac),
      UNIQUE KEY uniq_subnet_ip (subnet_id, ip),
      CONSTRAINT fk_dmb_dhcp_res_subnet
        FOREIGN KEY (subnet_id) REFERENCES dmb_dhcp_subnets(id)
        ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");

  // Defaults settings
  $st = $pdo->prepare("INSERT IGNORE INTO dmb_dhcp_settings(k,v) VALUES(?,?)");
  $st->execute(['dhcp_enabled', '0']);
}
dmb_dhcp_migrate($pdo);

/* ===== Load data ===== */
$settings = [];
$st = $pdo->query("SELECT k,v FROM dmb_dhcp_settings");
foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $settings[$r['k']] = $r['v'];
$dhcpEnabled = (int)($settings['dhcp_enabled'] ?? '0');

$subnets = $pdo->query("SELECT * FROM dmb_dhcp_subnets ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

/* ===== Theme CSS (si ton site le gère en DB, laisse header.php le faire normalement) ===== */
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>DoMyBox — DHCP</title>
  <?php
  // Si ton header global gère le thème, tu peux remplacer tout le <head> par require header.php.
  // Ici je mets juste une compat "soft" : si ton helper expose theme_css(), adapte au besoin.
  ?>
  <link rel="stylesheet" href="/theme/default/style.css">
  <style>
    .wrap{max-width:1200px;margin:0 auto;padding:18px}
    .row{display:flex;gap:14px;flex-wrap:wrap}
    .card{flex:1;min-width:320px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.10);border-radius:16px;padding:14px}
    h1{margin:0 0 12px;font-size:20px}
    h2{margin:0 0 10px;font-size:15px;opacity:.9}
    label{display:block;font-size:12px;opacity:.9;margin:10px 0 6px}
    input,select,textarea{width:100%;padding:10px 10px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.18);color:inherit;outline:none}
    textarea{min-height:70px;resize:vertical}
    .btn{display:inline-flex;gap:8px;align-items:center;justify-content:center;padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:inherit;cursor:pointer}
    .btn:hover{background:rgba(255,255,255,.10)}
    .btn.primary{border-color:rgba(120,220,255,.25);box-shadow:0 0 0 2px rgba(120,220,255,.08) inset}
    .btn.danger{border-color:rgba(255,120,120,.25);box-shadow:0 0 0 2px rgba(255,120,120,.08) inset}
    .pill{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);font-size:12px}
    table{width:100%;border-collapse:separate;border-spacing:0 8px}
    th{font-size:12px;text-align:left;opacity:.8;font-weight:600;padding:0 8px}
    td{padding:10px 8px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.10)}
    tr td:first-child{border-top-left-radius:12px;border-bottom-left-radius:12px}
    tr td:last-child{border-top-right-radius:12px;border-bottom-right-radius:12px}
    .muted{opacity:.7}
    .actions{display:flex;gap:8px;flex-wrap:wrap}
    .topbar{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px}
    .statusdot{width:9px;height:9px;border-radius:999px;background:#777;display:inline-block}
    .statusdot.on{background:#3ddc84}
    .statusdot.off{background:#ff6b6b}
    .small{font-size:12px;opacity:.85}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    @media (max-width:900px){.grid2{grid-template-columns:1fr}}
    .toast{position:fixed;right:16px;bottom:16px;max-width:420px;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.55);backdrop-filter: blur(10px);display:none}
    .toast.show{display:block}
  </style>
</head>
<body>
<div class="wrap">
  <div class="topbar">
    <h1>🧩 Module DHCP</h1>
    <div class="actions">
      <span class="pill">
        <span class="statusdot <?= $dhcpEnabled ? 'on':'off' ?>"></span>
        <b><?= $dhcpEnabled ? 'Actif (UI)':'Inactif (UI)' ?></b>
        <span class="muted">— applique pour démarrer/arrêter le service</span>
      </span>
      <button class="btn" id="btnRefreshLeases">🔄 Rafraîchir leases</button>
      <button class="btn primary" id="btnApply">✅ Appliquer (générer conf + restart)</button>
      <button class="btn danger" id="btnToggle"><?= $dhcpEnabled ? '⛔ Désactiver':'▶️ Activer' ?></button>
    </div>
  </div>

  <div class="row">
    <div class="card">
      <h2>1) Sous-réseaux (multi-subnets)</h2>

      <div class="grid2">
        <div>
          <label>Nom / Label</label>
          <input id="sn_label" placeholder="LAN Maison">
        </div>
        <div>
          <label>Interface (ex: eth0)</label>
          <input id="sn_iface" placeholder="eth0">
        </div>
        <div>
          <label>Réseau (CIDR)</label>
          <input id="sn_cidr" placeholder="192.168.10.0/24">
        </div>
        <div>
          <label>Range DHCP</label>
          <div class="grid2">
            <input id="sn_rs" placeholder="192.168.10.50">
            <input id="sn_re" placeholder="192.168.10.200">
          </div>
        </div>
        <div>
          <label>Gateway (router)</label>
          <input id="sn_router" placeholder="192.168.10.1">
        </div>
        <div>
          <label>DNS (1 / 2)</label>
          <div class="grid2">
            <input id="sn_dns1" placeholder="1.1.1.1">
            <input id="sn_dns2" placeholder="8.8.8.8 (option)">
          </div>
        </div>
        <div>
          <label>Domaine (option)</label>
          <input id="sn_domain" placeholder="home.lan">
        </div>
        <div>
          <label>Lease time (secondes)</label>
          <input id="sn_lease" type="number" min="60" step="60" value="86400">
        </div>
      </div>

      <div style="margin-top:12px" class="actions">
        <button class="btn primary" id="btnAddSubnet">➕ Ajouter sous-réseau</button>
      </div>

      <div style="margin-top:14px" class="small muted">
        Astuce : tu peux créer plusieurs subnets, chacun avec son interface. Si tu veux un DHCP multi-VLAN, c’est exactement ça.
      </div>

      <div style="margin-top:12px;overflow:auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Label</th>
              <th>IF</th>
              <th>CIDR</th>
              <th>Range</th>
              <th>GW</th>
              <th>DNS</th>
              <th>Lease</th>
              <th>On</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="subnetsBody">
            <?php foreach ($subnets as $s): ?>
              <tr data-id="<?= (int)$s['id'] ?>">
                <td><?= (int)$s['id'] ?></td>
                <td><?= htmlspecialchars((string)$s['label']) ?></td>
                <td><?= htmlspecialchars((string)$s['iface']) ?></td>
                <td><?= htmlspecialchars((string)$s['cidr']) ?></td>
                <td><?= htmlspecialchars((string)$s['range_start']) ?> → <?= htmlspecialchars((string)$s['range_end']) ?></td>
                <td><?= htmlspecialchars((string)$s['router']) ?></td>
                <td><?= htmlspecialchars((string)$s['dns1']) ?><?= $s['dns2'] ? ' , '.htmlspecialchars((string)$s['dns2']) : '' ?></td>
                <td><?= (int)$s['lease_time'] ?>s</td>
                <td><?= ((int)$s['enabled']===1) ? '✅' : '⛔' ?></td>
                <td class="actions">
                  <button class="btn" onclick="toggleSubnet(<?= (int)$s['id'] ?>)">On/Off</button>
                  <button class="btn danger" onclick="deleteSubnet(<?= (int)$s['id'] ?>)">Suppr</button>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$subnets): ?>
              <tr><td colspan="10" class="muted">Aucun sous-réseau. Ajoute-en un, puis “Appliquer”.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <h2>2) Réservations (MAC → IP)</h2>

      <div class="grid2">
        <div>
          <label>Sous-réseau</label>
          <select id="res_subnet">
            <option value="">— choisir —</option>
            <?php foreach ($subnets as $s): ?>
              <option value="<?= (int)$s['id'] ?>">
                #<?= (int)$s['id'] ?> — <?= htmlspecialchars((string)$s['label']) ?> (<?= htmlspecialchars((string)$s['cidr']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label>Hostname (option)</label>
          <input id="res_host" placeholder="pc-salon">
        </div>
        <div>
          <label>MAC</label>
          <input id="res_mac" placeholder="AA:BB:CC:DD:EE:FF">
        </div>
        <div>
          <label>IP réservée</label>
          <input id="res_ip" placeholder="192.168.10.10">
        </div>
      </div>
      <label>Note (option)</label>
      <input id="res_note" placeholder="NAS / Imprimante / etc">

      <div style="margin-top:12px" class="actions">
        <button class="btn primary" id="btnAddRes">➕ Ajouter réservation</button>
      </div>

      <div style="margin-top:12px;overflow:auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Subnet</th>
              <th>Hostname</th>
              <th>MAC</th>
              <th>IP</th>
              <th>On</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="reservationsBody">
            <!-- rempli en AJAX -->
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="card" style="margin-top:14px">
    <h2>3) Périphériques connectés (leases DHCP)</h2>
    <div class="small muted" style="margin-bottom:10px">
      Source : <code>/var/lib/dhcp/dhcpd.leases</code> (baux actifs). “Depuis quand” = start du bail.
    </div>

    <div style="overflow:auto">
      <table>
        <thead>
          <tr>
            <th>IP</th>
            <th>MAC</th>
            <th>Hostname</th>
            <th>Depuis</th>
            <th>Expire</th>
            <th>État</th>
          </tr>
        </thead>
        <tbody id="leasesBody">
          <tr><td colspan="6" class="muted">Clique “Rafraîchir leases”.</td></tr>
        </tbody>
      </table>
    </div>
  </div>

</div>

<div class="toast" id="toast"></div>

<script>
const CSRF = <?= json_encode($csrf) ?>;

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2400);
}

async function post(action, data={}){
  const fd = new FormData();
  fd.append('csrf', CSRF);
  fd.append('action', action);
  for (const k in data) fd.append(k, data[k]);
  const r = await fetch('api.php', {method:'POST', body:fd});
  const j = await r.json().catch(()=>({ok:0,error:'json'}));
  if (!j.ok) throw new Error(j.error || 'error');
  return j;
}

async function loadReservations(){
  const j = await post('list_reservations', {});
  const tb = document.getElementById('reservationsBody');
  tb.innerHTML = '';
  if (!j.items || !j.items.length){
    tb.innerHTML = `<tr><td colspan="7" class="muted">Aucune réservation.</td></tr>`;
    return;
  }
  for (const it of j.items){
    const on = it.enabled == 1 ? '✅' : '⛔';
    tb.insertAdjacentHTML('beforeend', `
      <tr>
        <td>${it.id}</td>
        <td>#${it.subnet_id}</td>
        <td>${escapeHtml(it.hostname||'')}</td>
        <td><code>${escapeHtml(it.mac)}</code></td>
        <td><code>${escapeHtml(it.ip)}</code></td>
        <td>${on}</td>
        <td class="actions">
          <button class="btn" onclick="toggleRes(${it.id})">On/Off</button>
          <button class="btn danger" onclick="deleteRes(${it.id})">Suppr</button>
        </td>
      </tr>
    `);
  }
}

async function loadLeases(){
  const j = await post('leases', {});
  const tb = document.getElementById('leasesBody');
  tb.innerHTML = '';
  if (!j.items || !j.items.length){
    tb.innerHTML = `<tr><td colspan="6" class="muted">Aucun lease actif (ou DHCP arrêté).</td></tr>`;
    return;
  }
  for (const it of j.items){
    tb.insertAdjacentHTML('beforeend', `
      <tr>
        <td><code>${escapeHtml(it.ip||'')}</code></td>
        <td><code>${escapeHtml(it.mac||'')}</code></td>
        <td>${escapeHtml(it.hostname||'')}</td>
        <td>${escapeHtml(it.start_human||'')}</td>
        <td>${escapeHtml(it.end_human||'')}</td>
        <td>${escapeHtml(it.state||'')}</td>
      </tr>
    `);
  }
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

async function toggleSubnet(id){
  try { await post('toggle_subnet', {id}); toast('Subnet modifié'); location.reload(); }
  catch(e){ toast('Erreur: ' + e.message); }
}
async function deleteSubnet(id){
  if(!confirm('Supprimer ce sous-réseau (et ses réservations) ?')) return;
  try { await post('delete_subnet', {id}); toast('Subnet supprimé'); location.reload(); }
  catch(e){ toast('Erreur: ' + e.message); }
}

async function toggleRes(id){
  try { await post('toggle_reservation', {id}); toast('Réservation modifiée'); loadReservations(); }
  catch(e){ toast('Erreur: ' + e.message); }
}
async function deleteRes(id){
  if(!confirm('Supprimer cette réservation ?')) return;
  try { await post('delete_reservation', {id}); toast('Réservation supprimée'); loadReservations(); }
  catch(e){ toast('Erreur: ' + e.message); }
}

document.getElementById('btnAddSubnet').addEventListener('click', async ()=>{
  try{
    const data = {
      label: document.getElementById('sn_label').value.trim(),
      iface: document.getElementById('sn_iface').value.trim(),
      cidr: document.getElementById('sn_cidr').value.trim(),
      range_start: document.getElementById('sn_rs').value.trim(),
      range_end: document.getElementById('sn_re').value.trim(),
      router: document.getElementById('sn_router').value.trim(),
      dns1: document.getElementById('sn_dns1').value.trim(),
      dns2: document.getElementById('sn_dns2').value.trim(),
      domain_name: document.getElementById('sn_domain').value.trim(),
      lease_time: document.getElementById('sn_lease').value.trim()
    };
    await post('add_subnet', data);
    toast('Sous-réseau ajouté');
    location.reload();
  }catch(e){
    toast('Erreur: ' + e.message);
  }
});

document.getElementById('btnAddRes').addEventListener('click', async ()=>{
  try{
    const data = {
      subnet_id: document.getElementById('res_subnet').value,
      hostname: document.getElementById('res_host').value.trim(),
      mac: document.getElementById('res_mac').value.trim(),
      ip: document.getElementById('res_ip').value.trim(),
      note: document.getElementById('res_note').value.trim()
    };
    await post('add_reservation', data);
    toast('Réservation ajoutée');
    document.getElementById('res_host').value = '';
    document.getElementById('res_mac').value = '';
    document.getElementById('res_ip').value = '';
    document.getElementById('res_note').value = '';
    loadReservations();
  }catch(e){
    toast('Erreur: ' + e.message);
  }
});

document.getElementById('btnApply').addEventListener('click', async ()=>{
  try{
    await post('apply', {});
    toast('Conf appliquée + service restart');
    loadLeases();
  }catch(e){
    toast('Erreur: ' + e.message);
  }
});

document.getElementById('btnToggle').addEventListener('click', async ()=>{
  try{
    await post('toggle_module', {});
    toast('Module (UI) basculé');
    location.reload();
  }catch(e){
    toast('Erreur: ' + e.message);
  }
});

document.getElementById('btnRefreshLeases').addEventListener('click', async ()=>{
  try{ await loadLeases(); toast('Leases rafraîchis'); }
  catch(e){ toast('Erreur: ' + e.message); }
});

loadReservations();
</script>
</body>
</html>