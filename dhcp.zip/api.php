<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/db.php';

require_login();

header('Content-Type: application/json; charset=utf-8');

function json_out(array $a, int $code=200): void {
  http_response_code($code);
  echo json_encode($a, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}

/* CSRF */
function csrf_check(): bool {
  return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals((string)$_SESSION['csrf'], (string)$_POST['csrf']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok'=>0,'error'=>'method'], 405);
if (!csrf_check()) json_out(['ok'=>0,'error'=>'csrf'], 403);

$action = (string)($_POST['action'] ?? '');

function norm_mac(string $mac): string {
  $m = strtolower(trim($mac));
  $m = str_replace(['-', '.', ' '], ':', $m);
  // compress multiple :
  $m = preg_replace('/:+/', ':', $m) ?? $m;
  return $m;
}

function valid_ip(string $ip): bool {
  return (bool)filter_var($ip, FILTER_VALIDATE_IP);
}

function must(bool $cond, string $err): void {
  if (!$cond) json_out(['ok'=>0,'error'=>$err], 400);
}

/* ===== Ensure tables exist (safe) ===== */
$pdo->exec("CREATE TABLE IF NOT EXISTS dmb_dhcp_settings (k VARCHAR(64) PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmb_dhcp_subnets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(128) NOT NULL,
  iface VARCHAR(64) NOT NULL DEFAULT 'eth0',
  cidr VARCHAR(32) NOT NULL,
  range_start VARCHAR(45) NOT NULL,
  range_end VARCHAR(45) NOT NULL,
  router VARCHAR(45) NOT NULL,
  dns1 VARCHAR(45) NOT NULL,
  dns2 VARCHAR(45) NOT NULL DEFAULT '',
  domain_name VARCHAR(255) NOT NULL DEFAULT '',
  lease_time INT NOT NULL DEFAULT 86400,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS dmb_dhcp_reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subnet_id INT NOT NULL,
  hostname VARCHAR(128) NOT NULL DEFAULT '',
  mac VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_subnet_mac (subnet_id, mac),
  UNIQUE KEY uniq_subnet_ip (subnet_id, ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$st = $pdo->prepare("INSERT IGNORE INTO dmb_dhcp_settings(k,v) VALUES(?,?)");
$st->execute(['dhcp_enabled', '0']);

/* ===== Root helpers =====
   install.sh creates sudoers whitelist for these 2 scripts (NOPASSWD):
   - /usr/local/sbin/dmb_dhcp_apply.sh
   - /usr/local/sbin/dmb_dhcp_leases.sh
*/
function sudo_run(string $cmd, array &$out=null, int &$rc=null): string {
  $out = [];
  $rc = 0;
  $full = "sudo -n " . $cmd . " 2>&1";
  $s = (string)exec($full, $out, $rc);
  return trim(implode("\n", $out));
}

if ($action === 'toggle_module') {
  $cur = (string)$pdo->query("SELECT v FROM dmb_dhcp_settings WHERE k='dhcp_enabled'")->fetchColumn();
  $new = ((int)$cur === 1) ? '0' : '1';
  $st = $pdo->prepare("UPDATE dmb_dhcp_settings SET v=? WHERE k='dhcp_enabled'");
  $st->execute([$new]);
  json_out(['ok'=>1,'enabled'=>(int)$new]);
}

/* Add subnet */
if ($action === 'add_subnet') {
  $label = trim((string)($_POST['label'] ?? ''));
  $iface = trim((string)($_POST['iface'] ?? 'eth0'));
  $cidr  = trim((string)($_POST['cidr'] ?? ''));
  $rs    = trim((string)($_POST['range_start'] ?? ''));
  $re    = trim((string)($_POST['range_end'] ?? ''));
  $router= trim((string)($_POST['router'] ?? ''));
  $dns1  = trim((string)($_POST['dns1'] ?? ''));
  $dns2  = trim((string)($_POST['dns2'] ?? ''));
  $domain= trim((string)($_POST['domain_name'] ?? ''));
  $lease = (int)($_POST['lease_time'] ?? 86400);

  must($label !== '', 'label');
  must($iface !== '', 'iface');
  must($cidr !== '' && strpos($cidr,'/') !== false, 'cidr');
  must(valid_ip($rs) && valid_ip($re) && valid_ip($router) && valid_ip($dns1), 'ip');
  must($lease >= 60, 'lease');

  $st = $pdo->prepare("INSERT INTO dmb_dhcp_subnets(label,iface,cidr,range_start,range_end,router,dns1,dns2,domain_name,lease_time,enabled)
                       VALUES(?,?,?,?,?,?,?,?,?,?,1)");
  $st->execute([$label,$iface,$cidr,$rs,$re,$router,$dns1,$dns2,$domain,$lease]);
  json_out(['ok'=>1,'id'=>(int)$pdo->lastInsertId()]);
}

if ($action === 'toggle_subnet') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0, 'id');
  $cur = (int)($pdo->prepare("SELECT enabled FROM dmb_dhcp_subnets WHERE id=?")->execute([$id]) ? (int)$pdo->query("SELECT enabled FROM dmb_dhcp_subnets WHERE id={$id}")->fetchColumn() : 1);
  // safer:
  $st = $pdo->prepare("SELECT enabled FROM dmb_dhcp_subnets WHERE id=?");
  $st->execute([$id]);
  $cur = (int)$st->fetchColumn();
  $new = ($cur===1) ? 0 : 1;
  $st = $pdo->prepare("UPDATE dmb_dhcp_subnets SET enabled=? WHERE id=?");
  $st->execute([$new,$id]);
  json_out(['ok'=>1,'enabled'=>$new]);
}

if ($action === 'delete_subnet') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0, 'id');
  $st = $pdo->prepare("DELETE FROM dmb_dhcp_subnets WHERE id=?");
  $st->execute([$id]);
  json_out(['ok'=>1]);
}

/* Reservations */
if ($action === 'add_reservation') {
  $subnetId = (int)($_POST['subnet_id'] ?? 0);
  $hostname = trim((string)($_POST['hostname'] ?? ''));
  $mac      = norm_mac((string)($_POST['mac'] ?? ''));
  $ip       = trim((string)($_POST['ip'] ?? ''));
  $note     = trim((string)($_POST['note'] ?? ''));

  must($subnetId>0, 'subnet');
  must($mac !== '' && preg_match('/^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i', $mac) === 1, 'mac');
  must(valid_ip($ip), 'ip');

  // ensure subnet exists
  $st = $pdo->prepare("SELECT id FROM dmb_dhcp_subnets WHERE id=?");
  $st->execute([$subnetId]);
  must((int)$st->fetchColumn() > 0, 'subnet');

  $st = $pdo->prepare("INSERT INTO dmb_dhcp_reservations(subnet_id,hostname,mac,ip,note,enabled)
                       VALUES(?,?,?,?,?,1)");
  try{
    $st->execute([$subnetId,$hostname,$mac,$ip,$note]);
  }catch(Throwable $e){
    json_out(['ok'=>0,'error'=>'duplicate_mac_or_ip'], 409);
  }
  json_out(['ok'=>1,'id'=>(int)$pdo->lastInsertId()]);
}

if ($action === 'list_reservations') {
  $items = $pdo->query("SELECT * FROM dmb_dhcp_reservations ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  json_out(['ok'=>1,'items'=>$items]);
}

if ($action === 'toggle_reservation') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("SELECT enabled FROM dmb_dhcp_reservations WHERE id=?");
  $st->execute([$id]);
  $cur = (int)$st->fetchColumn();
  $new = ($cur===1) ? 0 : 1;
  $st = $pdo->prepare("UPDATE dmb_dhcp_reservations SET enabled=? WHERE id=?");
  $st->execute([$new,$id]);
  json_out(['ok'=>1,'enabled'=>$new]);
}

if ($action === 'delete_reservation') {
  $id = (int)($_POST['id'] ?? 0);
  must($id>0,'id');
  $st = $pdo->prepare("DELETE FROM dmb_dhcp_reservations WHERE id=?");
  $st->execute([$id]);
  json_out(['ok'=>1]);
}

/* Apply config + restart service */
if ($action === 'apply') {
  // module UI enabled?
  $enabled = (int)$pdo->query("SELECT v FROM dmb_dhcp_settings WHERE k='dhcp_enabled'")->fetchColumn();
  $cmd = "/usr/local/sbin/dmb_dhcp_apply.sh " . ($enabled===1 ? "enable" : "disable");
  $out = []; $rc=0;
  $log = sudo_run($cmd, $out, $rc);
  if ($rc !== 0) json_out(['ok'=>0,'error'=>'apply_failed','details'=>$log], 500);
  json_out(['ok'=>1,'log'=>$log]);
}

/* Read leases */
if ($action === 'leases') {
  $out=[]; $rc=0;
  $log = sudo_run("/usr/local/sbin/dmb_dhcp_leases.sh", $out, $rc);
  if ($rc !== 0) json_out(['ok'=>0,'error'=>'leases_failed','details'=>$log], 500);
  $j = json_decode($log, true);
  if (!is_array($j)) json_out(['ok'=>0,'error'=>'leases_bad_json'], 500);
  json_out(['ok'=>1,'items'=>$j]);
}

json_out(['ok'=>0,'error'=>'unknown_action'], 400);