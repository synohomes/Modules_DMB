(async function(){
  const elState = document.getElementById('st-state');
  const elMsg   = document.getElementById('st-msg');
  const elTime  = document.getElementById('st-time');
  const elRaw   = document.getElementById('raw');

  const btnInstall = document.getElementById('btn-install');
  const btnStatus  = document.getElementById('btn-status');
  const btnRemove  = document.getElementById('btn-remove');

  function showRaw(obj){
    elRaw.textContent = (typeof obj === 'string') ? obj : JSON.stringify(obj, null, 2);
  }

  async function callAgent(action){
    // modules.php appelle déjà l’agent en local, mais ici on teste direct:
    // On appelle /dmd-agent.php (local) pour status/install/remove
    const form = new URLSearchParams();
    form.set('action', action);
    form.set('module', window.DMD.moduleId);

    const r = await fetch('/dmd-agent.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString()
    });

    const txt = await r.text();
    let j;
    try { j = JSON.parse(txt); } catch(e){ j = { ok:0, raw:txt }; }
    showRaw(j);

    // status JSON est écrit dans /data/modules/<module>.json
    if (action === 'status' && j && j.status) {
      elState.textContent = (j.status.installed ? 'INSTALLÉ' : 'NON INSTALLÉ');
      elMsg.textContent   = (j.status.message || '-');
      elTime.textContent  = (j.status.ts || '-');
    } else {
      // fallback
      elState.textContent = j.ok ? 'OK' : 'ERREUR';
      elMsg.textContent   = j.error || j.err || '-';
      elTime.textContent  = '-';
    }
  }

  async function refresh(){
    await callAgent('status');
  }

  if (btnInstall) btnInstall.addEventListener('click', async ()=>{
    btnInstall.disabled = true;
    try { await callAgent('install'); await refresh(); }
    finally { btnInstall.disabled = false; }
  });

  if (btnStatus) btnStatus.addEventListener('click', async ()=>{
    btnStatus.disabled = true;
    try { await refresh(); }
    finally { btnStatus.disabled = false; }
  });

  if (btnRemove) btnRemove.addEventListener('click', async ()=>{
    if (!confirm('Supprimer le module (simulation) ?')) return;
    btnRemove.disabled = true;
    try { await callAgent('remove'); await refresh(); }
    finally { btnRemove.disabled = false; }
  });

  refresh();
})();