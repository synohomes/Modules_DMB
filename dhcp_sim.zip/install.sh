#!/usr/bin/env bash
set -euo pipefail

# Simulation d'installation : on écrit juste un fichier dans /data/modules
mkdir -p /data/modules
echo "dhcp_sim installed $(date)" > /data/modules/dhcp_sim.installed
exit 0