#!/usr/bin/env bash
set -euo pipefail

if [[ -f /data/modules/dhcp_sim.installed ]]; then
  echo "installed"
else
  echo "not_installed"
fi