#!/usr/bin/env bash
set -euo pipefail

rm -f /data/modules/dhcp_sim.installed
exit 0