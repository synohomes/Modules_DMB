<?php
declare(strict_types=1);
session_start();
if (empty($_SESSION['user_id'])) { header('Location:/login.php'); exit; }

require __DIR__ . '/../../asset/db.php';

function setting(PDO $pdo, string $k, string $default=''): string {
  try{
    $st = $pdo->prepare("SELECT v FROM settings WHERE k=? LIMIT 1");
    $st->execute([$k]);
    $v = $st->fetchColumn();
    return (is_string($v) && $v !== '') ? $v : $default;
  }catch(Throwable $e){
    return $default;
  }
}

$boxName  = setting($pdo, 'box_name', 'Votre DoMyBox');
$theme    = setting($pdo, 'theme', 'default');
$themeCss = "themes/" . basename($theme) . "/style.css";
if (!is_file(__DIR__ . '/../../' . $themeCss)) $themeCss = "themes/default/style.css";

$role = (string)($_SESSION['role'] ?? 'user');
$isAdmin = in_array($role, ['admin','superadmin'], true);

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = (string)$_SESSION['csrf_token'];
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DHCP SIM - <?= htmlspecialchars($boxName) ?></title>
<link rel="stylesheet" href="/<?= htmlspecialchars($themeCss) ?>">
<style>
  .modwrap{max-width:980px;margin:0 auto;padding:18px}
  .card{border:1px solid var(--border);background:var(--panel-bg);border-radius:12px;padding:16px;margin:12px 0}
  .row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
  .pill{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--border);border-radius:999px;padding:6px 12px;background:rgba(255,255,255,.04);font-size:12px}
  .muted{opacity:.75;font-size:12px}
  .btn{all:unset;cursor:pointer;padding:10px 14px;border-radius:10px;border:1px solid var(--border);background:rgba(255,255,255,.06);font-weight:700}
  .btn:hover{filter:brightness(1.15)}
  .btn.primary{background:var(--accent);border-color:transparent;color:#fff}
  .btn.danger{background:rgba(255,0,0,.14);border-color:rgba(255,0,0,.25)}
  code{font-family:ui-monospace,Menlo,Consolas,monospace}
  .log{white-space:pre-wrap;background:rgba(0,0,0,.25);border:1px solid var(--border);border-radius:10px;padding:10px;min-height:64px}
</style>
</head>
<body>
<div class="modwrap">

  <div class="card">
    <h2 style="margin:0 0 8px">DHCP (Simulation)</h2>
    <div class="muted">
      Module de test : vérifie que ton <code>modules.php</code> + <code>dmd-agent.php</code> gèrent bien install / status / remove.
      <br>⚠️ Aucun service DHCP réel n’est installé.
    </div>
  </div>

  <div class="card">
    <div class="row">
      <span class="pill">ID : <b>dhcp_sim</b></span>
      <span class="pill">Statut : <b id="st-state">…</b></span>
      <span class="pill">Message : <span id="st-msg" class="muted">…</span></span>
      <span class="pill">Time : <span id="st-time" class="muted">…</span></span>
    </div>
    <div style="height:10px"></div>

    <?php if ($isAdmin): ?>
      <div class="row">
        <button class="btn primary" id="btn-install">Installer (simulé)</button>
        <button class="btn" id="btn-status">Rafraîchir statut</button>
        <button class="btn danger" id="btn-remove">Supprimer (simulé)</button>
      </div>
    <?php else: ?>
      <div class="muted">Seuls les admins peuvent installer / supprimer un module.</div>
    <?php endif; ?>

    <div style="height:14px"></div>
    <div class="muted">Retour agent :</div>
    <div id="raw" class="log"></div>
  </div>

</div>

<script>
  window.DMD = {
    csrf: <?= json_encode($csrf) ?>,
    isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
    moduleId: "dhcp_sim"
  };
</script>
<script src="dhcp_sim.js"></script>
</body>
</html>