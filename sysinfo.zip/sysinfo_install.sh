#!/bin/bash

echo "[+] Installation des paquets nécessaires..."

# Paquets système requis
sudo apt update
sudo apt install -y lshw curl net-tools jq sysstat ifmetric dmidecode iproute2

echo "[+] Paquets installés."

# Activation de la collecte CPU/RAM (si nécessaire)
if [ -f /etc/default/sysstat ]; then
  sudo sed -i 's/ENABLED="false"/ENABLED="true"/' /etc/default/sysstat
  sudo systemctl enable sysstat
  sudo systemctl start sysstat
fi

echo "[+] Configuration terminée."
