CREATE DATABASE IF NOT EXISTS domydesk_sysinfo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE domydesk_sysinfo;

CREATE TABLE IF NOT EXISTS system_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hostname VARCHAR(255),
    serial_number VARCHAR(255),
    cpu_id VARCHAR(255),
    total_ram_mb INT,
    used_ram_mb INT,
    cpu_usage_percent FLOAT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS network_interfaces (
    id INT AUTO_INCREMENT PRIMARY KEY,
    interface_name VARCHAR(100),
    ip_address VARCHAR(100),
    mac_address VARCHAR(100),
    type VARCHAR(50),
    speed_mbps INT,
    rx_rate_kbps FLOAT,
    tx_rate_kbps FLOAT,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS disks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mount_point VARCHAR(255),
    fs_type VARCHAR(100),
    total_space_mb INT,
    used_space_mb INT,
    usage_percent FLOAT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
