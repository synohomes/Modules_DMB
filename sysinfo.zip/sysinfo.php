<?php
require_once __DIR__.'/../../core/connect.php';

$db = new PDO('mysql:host=localhost;dbname=domydesk_sysinfo;charset=utf8mb4', 'root', 'root'); // adapte les identifiants

// Récupération des données
$sys = $db->query("SELECT * FROM system_info ORDER BY updated_at DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$ifaces = $db->query("SELECT * FROM network_interfaces ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$disks = $db->query("SELECT * FROM disks ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="sysinfo-module">
  <h2>🔧 Informations système</h2>
  <ul>
    <li><b>Nom hôte :</b> <?= $sys['hostname'] ?? 'NC' ?></li>
    <li><b>N° de série :</b> <?= $sys['serial_number'] ?? 'NC' ?></li>
    <li><b>CPU ID :</b> <?= $sys['cpu_id'] ?? 'NC' ?></li>
    <li><b>RAM utilisée :</b> <?= $sys['used_ram_mb'] ?? 0 ?> / <?= $sys['total_ram_mb'] ?? 0 ?> MB</li>
    <li><b>CPU utilisé :</b> <?= round($sys['cpu_usage_percent'] ?? 0, 1) ?>%</li>
  </ul>

  <h3>📡 Interfaces réseau</h3>
  <ul>
    <?php foreach ($ifaces as $net): ?>
      <li>
        <b><?= $net['interface_name'] ?></b> (<?= $net['type'] ?>) - <?= $net['ip_address'] ?>  
        <br>Débit RX: <?= round($net['rx_rate_kbps'], 1) ?> kbps / TX: <?= round($net['tx_rate_kbps'], 1) ?> kbps  
        <br>MAC: <?= $net['mac_address'] ?> / Speed: <?= $net['speed_mbps'] ?> Mbps
      </li>
    <?php endforeach; ?>
  </ul>

  <h3>💾 Disques</h3>
  <ul>
    <?php foreach ($disks as $disk): ?>
      <li>
        <?= $disk['mount_point'] ?> (<?= $disk['fs_type'] ?>):  
        <?= $disk['used_space_mb'] ?>/<?= $disk['total_space_mb'] ?> MB (<?= round($disk['usage_percent'], 1) ?>%)
      </li>
    <?php endforeach; ?>
  </ul>
</div>
