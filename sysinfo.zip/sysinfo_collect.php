<?php
$db = new PDO('mysql:host=localhost;dbname=domydesk_sysinfo;charset=utf8mb4', 'root', 'root'); // adapte selon config

// Infos système
$hostname = trim(shell_exec("hostname"));
$serial = trim(shell_exec("cat /proc/cpuinfo | grep Serial | awk '{print $3}'"));
$cpuid = trim(shell_exec("cat /proc/cpuinfo | grep 'Hardware' | awk '{print $3}'"));
$total_ram = (int)(shell_exec("free -m | awk '/Mem:/ {print $2}'"));
$used_ram = (int)(shell_exec("free -m | awk '/Mem:/ {print $3}'"));
$cpu_usage = (float)(shell_exec("top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'"));

// Insert ou Update
$db->exec("DELETE FROM system_info");
$stmt = $db->prepare("INSERT INTO system_info (hostname, serial_number, cpu_id, total_ram_mb, used_ram_mb, cpu_usage_percent) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->execute([$hostname, $serial, $cpuid, $total_ram, $used_ram, $cpu_usage]);

// Interfaces réseau
$db->exec("DELETE FROM network_interfaces");
$ifaces = explode("\n", trim(shell_exec("ip -o -4 addr show | awk '{print $2, $4}'")));
foreach ($ifaces as $line) {
  [$iface, $ip] = explode(" ", $line);
  $mac = trim(shell_exec("cat /sys/class/net/$iface/address"));
  $type = file_exists("/sys/class/net/$iface/wireless") ? 'WiFi' : 'Ethernet';
  $speed = (int)(@file_get_contents("/sys/class/net/$iface/speed"));
  $rx = (int)(trim(shell_exec("cat /sys/class/net/$iface/statistics/rx_bytes"))) / 1024;
  $tx = (int)(trim(shell_exec("cat /sys/class/net/$iface/statistics/tx_bytes"))) / 1024;

  $stmt = $db->prepare("INSERT INTO network_interfaces (interface_name, ip_address, mac_address, type, speed_mbps, rx_rate_kbps, tx_rate_kbps) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->execute([$iface, $ip, $mac, $type, $speed, $rx, $tx]);
}

// Disques
$db->exec("DELETE FROM disks");
$mounts = explode("\n", trim(shell_exec("df -T -BM | grep '^/dev/'")));
foreach ($mounts as $m) {
  $parts = preg_split('/\s+/', $m);
  if (count($parts) >= 7) {
    [$dev, $fs, $size, $used, , , $mnt] = $parts;
    $stmt = $db->prepare("INSERT INTO disks (mount_point, fs_type, total_space_mb, used_space_mb, usage_percent) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$mnt, $fs, (int)$size, (int)$used, ((int)$used / (int)$size) * 100]);
  }
}
