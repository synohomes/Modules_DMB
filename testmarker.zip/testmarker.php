<?php
$marker = '/opt/domybox/testmarker.installed';
echo '<div style="padding:15px">';
echo '<h2>TestMarker</h2>';
if (is_file($marker)) {
  echo '<p style="color:#2ecc71">✅ Install OK</p>';
  echo '<pre>'.htmlspecialchars(file_get_contents($marker)).'</pre>';
} else {
  echo '<p style="color:#e74c3c">❌ Marker absent</p>';
}
echo '</div>';
