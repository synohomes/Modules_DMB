#!/usr/bin/env bash
set -e
mkdir -p /opt/domybox
echo "installed $(date -Is)" > /opt/domybox/testmarker.installed
chmod 644 /opt/domybox/testmarker.installed
