#!/usr/bin/env bash
set -e
rm -f /opt/domybox/testmarker.installed
